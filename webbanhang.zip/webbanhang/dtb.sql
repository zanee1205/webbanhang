SELECT * FROM categories;
